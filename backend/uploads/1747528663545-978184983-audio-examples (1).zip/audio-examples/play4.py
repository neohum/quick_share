# pythonbasics.org
# apt install mpg123

import os

file = "file.mp3"
os.system("mpg123 " + file)
